module.exports = {
      secret : "KAM-secret-key"
}