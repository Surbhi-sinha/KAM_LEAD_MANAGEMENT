module.exports ={
      HOST:'localhost',
      USER:"root",
      PASSWORD:"Kam123456",
      DB:"kam_lead_management",
      dialect:"mysql",
}